package ob_apikeys

import (
	"github.com/dgrijalva/jwt-go"
	jsoniter "github.com/json-iterator/go"
	"io/ioutil"
	"log"
	"net/http"
	"oceanbolt.com/iamservice/pkg/utl/rsaauth"
	"os"
	"strings"
	"time"
)

func RefreshAuth0Token() {

	var netClient = &http.Client{
		Timeout: time.Second * 10,
	}

	type auth0token struct {
		Access_token string
		Token_type string
	}

	url := "https://oceanbolt.eu.auth0.com/oauth/token"

	AUTH0_MGMT_APIKEY_ID := os.Getenv("AUTH0_MGMT_APIKEY_ID")
	if AUTH0_MGMT_APIKEY_ID == "" {
		log.Fatal("Error AUTH0_MGMT_APIKEY_ID env var is missing")
	}

	AUTH0_MGMT_APIKEY_SECRET := os.Getenv("AUTH0_MGMT_APIKEY_SECRET")
	if AUTH0_MGMT_APIKEY_SECRET == "" {
		log.Fatal("Error AUTH0_MGMT_APIKEY_SECRET env var is missing")
	}

	payload := strings.NewReader("{\"client_id\":\""+ AUTH0_MGMT_APIKEY_ID +"\",\"client_secret\":\""+AUTH0_MGMT_APIKEY_SECRET+"\",\"audience\":\"https://oceanbolt.eu.auth0.com/api/v2/\",\"grant_type\":\"client_credentials\"}")

	req, _ := http.NewRequest("POST", url, payload)

	req.Header.Add("content-type", "application/json")

	res, _ := netClient.Do(req)

	var auth0tokenParsed auth0token

	defer res.Body.Close()
	body, _ := ioutil.ReadAll(res.Body)

	err := jsoniter.Unmarshal(body,&auth0tokenParsed)
	if err != nil {
		log.Fatal(err)
	}
	os.Setenv("AUTHZERO_MGMT_TOKEN",auth0tokenParsed.Access_token)

}

func CheckIfAuth0TokenMustBeRefreshed() {

	AUTH0_MGMT_TOKEN := os.Getenv("AUTHZERO_MGMT_TOKEN")
	if AUTH0_MGMT_TOKEN == "" {
		log.Printf("Auth0 Management token is not set... refreshing \n")
		RefreshAuth0Token()
		AUTH0_MGMT_TOKEN = os.Getenv("AUTHZERO_MGMT_TOKEN")
	}

	keyFunc := func(t *jwt.Token) (interface{}, error) {
		signingKey, err := rsaauth.GetJWKS(t)
		if err != nil {
			panic(err)
		}
		return signingKey, nil
	}

	token := new(jwt.Token)
	token, err := jwt.Parse(AUTH0_MGMT_TOKEN, keyFunc)
	if err != nil {
		log.Print(AUTH0_MGMT_TOKEN)
		log.Print(err)
		log.Fatal("Token could not be decrypted")
	}

	claims := token.Claims.(jwt.MapClaims)
	timeFloat := claims["exp"].(float64)
	timeInt64 := int64(timeFloat)

	exp := time.Unix(timeInt64,0)

	if exp.After(time.Now().Add(30 * time.Minute)) {
		RefreshAuth0Token()
	}
}