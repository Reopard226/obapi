package ob_apikeys

import (
	"github.com/dgrijalva/jwt-go"
	"log"
	"math/rand"
	"oceanbolt.com/iamservice/models/apiaccess"
	"os"
	"strings"
	"time"
)

func CreateKey(userId string,keyTag string, expires time.Time) apiaccess.Ob_api_key_No_Id {

	key := os.Getenv("JWKS_RS256_PRIVATE_KEY")
	if key == "" {
		log.Fatal("Error 'JWKS_RS256_PRIVATE_KEY' variable not set")
	}
	keyByte := []byte(key)


	parsedKey, err := jwt.ParseRSAPrivateKeyFromPEM(keyByte)
	if err != nil {
		log.Fatal("Key could not be parsed")
	}

	obkid := getKeyId(16)

	current_signing_key := "ob-key1"

	token := jwt.NewWithClaims(jwt.SigningMethodRS256, jwt.MapClaims{
		"aud": "https://api.oceanbolt.com",
		"iss": "https://oceanbolt.eu.auth0.com/",
		"ktype": "apikey",
		"obkid": obkid,
		"sub": userId,
		"iat": time.Now().Unix(),
		"exp": expires.Unix(),
	})

	token.Header["kid"] = current_signing_key


	signedToken, err := token.SignedString(parsedKey)
	if err != nil {
		log.Fatal("Token could not be signed")
	}

	obkey := apiaccess.Ob_api_key_No_Id{
		Apikey_Id:      obkid,
		Apikey_Secret:  signedToken,
		Expires:        expires.Unix(),
		User_Id:        userId,
		Signing_Key_Id: current_signing_key,
		Key_Tag:keyTag,

	}

	return obkey

}


func getKeyId(length int) string {
	rand.Seed(time.Now().UnixNano())
	chars := []rune("ABCDEFGHIJKLMNOPQRSTUVWXYZ" +
		"abcdefghijklmnopqrstuvwxyz" +
		"0123456789")

	var b strings.Builder
	for i := 0; i < length; i++ {
		b.WriteRune(chars[rand.Intn(len(chars))])
	}
	return b.String()
}