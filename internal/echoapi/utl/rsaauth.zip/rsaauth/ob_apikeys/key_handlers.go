package ob_apikeys

import (
	"context"
	"fmt"
	"github.com/dgrijalva/jwt-go"
	jsoniter "github.com/json-iterator/go"
	"github.com/labstack/echo"
	"io/ioutil"
	"log"
	"net/http"
	"oceanbolt.com/iamservice/db"
	"oceanbolt.com/iamservice/pkg/utl/model/apiaccess"
	"os"
	"strconv"
	"sync"
	"time"
)

func InsertKeyHandler(c echo.Context) error {
	//user_id := c.Param("user_id")
	user := c.Get("user").(*jwt.Token)
	claims := user.Claims.(jwt.MapClaims)

	userId := claims["sub"].(string)
	if userId == "" {
		log.Fatal("Error - user id is missing from claim")
	}

	type CreateKeyPayload struct {
		Exp int64
		Tag string
	}

	var payload CreateKeyPayload
	err := jsoniter.NewDecoder(c.Request().Body).Decode(&payload)
	if err != nil {
		return c.String(http.StatusBadRequest, fmt.Sprintf("Could not parse request payload - 'tag' entry should be string, 'exp' entry should be int64 and value should be seconds since epoch"))
	}

	if payload.Tag == "" {
		return c.String(http.StatusBadRequest, fmt.Sprintf("Missing 'tag' entry in request payload"))
	}

	expiresTime := time.Unix(payload.Exp, 0)

	ctx := context.Background()

	mongoClient := db.GetMongoClient()
	err = mongoClient.Connect(ctx)
	if err != nil {
		log.Fatal(err)
	}
	defer mongoClient.Disconnect(ctx)

	key := CreateKey(userId, payload.Tag, expiresTime)

	db.InsertNewKey(ctx, mongoClient, apiaccess.Ob_api_key_No_Id_no_Secret{
		Apikey_Id:      key.Apikey_Id,
		Expires:        key.Expires,
		User_Id:        key.User_Id,
		Signing_Key_Id: key.Signing_Key_Id,
		Key_Tag:        key.Key_Tag,
	})

	json, err := jsoniter.Marshal(key)

	return c.JSONBlob(http.StatusOK, json)

}

func msToTime(ms string) (time.Time, error) {
	msInt, err := strconv.ParseInt(ms, 10, 64)
	if err != nil {
		return time.Time{}, err
	}

	return time.Unix(0, msInt*int64(time.Millisecond)), nil
}

func ListKeysHandler(c echo.Context) error {
	user := c.Get("user").(*jwt.Token)
	claims := user.Claims.(jwt.MapClaims)

	userId := claims["sub"].(string)
	if userId == "" {
		log.Fatal("Error - user id is missing from claim")
	}

	ctx := context.Background()

	mongoClient := db.GetMongoClient()
	err := mongoClient.Connect(ctx)
	if err != nil {
		log.Fatal(err)
	}
	defer mongoClient.Disconnect(ctx)

	keys := db.ListKeys(ctx, mongoClient, userId)

	json, err := jsoniter.Marshal(keys)
	if err != nil {
		log.Fatal(err)
	}

	return c.JSONBlob(http.StatusOK, json)

}

func DeleteKeyHandler(c echo.Context) error {
	key_id := c.Param("key_id")
	user := c.Get("user").(*jwt.Token)
	claims := user.Claims.(jwt.MapClaims)

	user_id := claims["sub"].(string)

	log.Println("Key id: " + key_id)
	ctx := context.Background()

	mongoClient := db.GetMongoClient()
	err := mongoClient.Connect(ctx)
	if err != nil {
		log.Fatal(err)
	}
	defer mongoClient.Disconnect(ctx)

	db.DeleteKey(ctx, mongoClient, key_id, user_id)

	return c.String(http.StatusNoContent, "Key Deleted")

}

type Auth0Permissions struct {
	Permission_name string
}

func GetPermissionsForUser(userId string, apikeyId string) []interface{} {

	var netClient = &http.Client{
		Timeout: time.Second * 10,
	}

	CheckIfAuth0TokenMustBeRefreshed()

	ctx := context.Background()
	mongoClient := db.GetMongoClient()

	err := mongoClient.Connect(ctx)
	if err != nil {
		log.Fatal(err)
	}
	defer mongoClient.Disconnect(ctx)

	start := time.Now()

	var auth0wg sync.WaitGroup
	auth0wg.Add(3)
	permissionsParsed := DispatchPermissionsForUser(&auth0wg, netClient, userId)
	blocked := DispatchIsUserBlocker(&auth0wg, netClient, userId)
	keyExists := db.CheckKeyIsActive(&auth0wg, ctx, mongoClient, apikeyId)
	auth0wg.Wait()

	fmt.Printf("Time taken to validate: %vms\n", (time.Now().UnixNano()-start.UnixNano())/1000000)

	var emptyInterface []interface{}
	if blocked || !keyExists {
		fmt.Printf("Blocked user trying to access, user_id: %s\n", userId)
		return emptyInterface
	}

	interfaces := make([]interface{}, len(permissionsParsed))

	for k, v := range permissionsParsed {
		interfaces[k] = v.Permission_name
	}

	return interfaces

}

func DispatchPermissionsForUser(wg *sync.WaitGroup, netClient *http.Client, userId string) []Auth0Permissions {

	start := time.Now()
	url := "https://oceanbolt.eu.auth0.com/api/v2/users/" + userId + "/permissions"

	AUTH0_MGMT_TOKEN := os.Getenv("AUTHZERO_MGMT_TOKEN")
	if AUTH0_MGMT_TOKEN == "" {
		log.Printf("Auth0 Management token is not set... refreshing \n")
		RefreshAuth0Token()
		AUTH0_MGMT_TOKEN = os.Getenv("AUTHZERO_MGMT_TOKEN")
		if AUTH0_MGMT_TOKEN == "" {
			log.Print("Missing AUTHZERO_MGMT_TOKEN env var")
		}
	}

	req, _ := http.NewRequest("GET", url, nil)
	req.Header.Add("authorization", "Bearer "+AUTH0_MGMT_TOKEN)

	response, err := netClient.Do(req)
	if err != nil {
		panic(err)
	}
	defer response.Body.Close()
	body, err := ioutil.ReadAll(response.Body)
	if err != nil {
		fmt.Printf("%s", err)
		os.Exit(1)
	}

	var permissionsParsed []Auth0Permissions

	err = jsoniter.Unmarshal(body, &permissionsParsed)
	if err != nil {
		panic(err)
	}
	wg.Done()
	fmt.Printf("Time taken to fetch permissions: %vms\n", (time.Now().UnixNano()-start.UnixNano())/1000000)
	return permissionsParsed
}

func DispatchIsUserBlocker(wg *sync.WaitGroup, netClient *http.Client, userId string) bool {
	start := time.Now()
	type blocked struct {
		Blocked bool
	}

	url := "https://oceanbolt.eu.auth0.com/api/v2/users/" + userId + "?fields=blocked"

	AUTH0_MGMT_TOKEN := os.Getenv("AUTHZERO_MGMT_TOKEN")
	if AUTH0_MGMT_TOKEN == "" {
		log.Printf("Auth0 Management token is not set... refreshing \n")
		RefreshAuth0Token()
		AUTH0_MGMT_TOKEN = os.Getenv("AUTHZERO_MGMT_TOKEN")
		if AUTH0_MGMT_TOKEN == "" {
			log.Print("Missing AUTHZERO_MGMT_TOKEN env var")
		}
	}

	req, _ := http.NewRequest("GET", url, nil)
	req.Header.Add("authorization", "Bearer "+AUTH0_MGMT_TOKEN)

	response, err := netClient.Do(req)
	if err != nil {
		panic(err)
	}
	defer response.Body.Close()
	body, err := ioutil.ReadAll(response.Body)
	if err != nil {
		fmt.Printf("%s", err)
		os.Exit(1)
	}

	var blockedParsed blocked

	err = jsoniter.Unmarshal(body, &blockedParsed)
	if err != nil {
		panic(err)
	}
	wg.Done()
	fmt.Printf("Time taken to check if user is blocked: %vms\n", (time.Now().UnixNano()-start.UnixNano())/1000000)
	return blockedParsed.Blocked
}
