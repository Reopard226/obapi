package rsaauth

import (
	"fmt"
	"github.com/dgrijalva/jwt-go"
	jsoniter "github.com/json-iterator/go"
	"io/ioutil"
	"log"
	"net/http"
	"os"
	"strings"
	"time"
)

type JWTKey struct {
	Alg string   `json:"alg"`
	Kty string   `json:"kty"`
	Use string   `json:"use"`
	X5c []string `json:"x5c"`
	N   string   `json:"n"`
	E   string   `json:"e"`
	Kid string   `json:"kid"`
	X5t string   `json:"x5t"`
}

type JWTKeys struct {
	Keys []JWTKey `json:"keys"`
}

func fileExists(filename string) bool {
	info, err := os.Stat(filename)
	if os.IsNotExist(err) {
		return false
	}
	return !info.IsDir()
}

func GetCachedJWKSKeys() JWTKeys {

	keyFileName := "AUTH0_RSA_JWK.json"

	jwtKeys := JWTKeys{}
	if fileExists(keyFileName) {
		output, err := ioutil.ReadFile(keyFileName)
		if err != nil {
			panic(err)
		}
		err = jsoniter.Unmarshal([]byte(output), &jwtKeys)
		if err != nil {
			panic(err)
		}
	} else {
		log.Print("Keyfile does not exist, fetching from AUTH0")
		jwtKeys = ParseJWKSAuth0()
		marshalledToken, err := jsoniter.Marshal(jwtKeys)
		if err != nil {
			panic(err)
		}
		ioutil.WriteFile(keyFileName, marshalledToken, 0644)
	}


	return jwtKeys
}

func ParseJWKSAuth0() JWTKeys {

	var netClient = &http.Client{
		Timeout: time.Second * 10,
	}

	response, err := netClient.Get("https://oceanbolt.eu.auth0.com/.well-known/jwks.json")
	if err != nil {
		panic(err)
	}
	defer response.Body.Close()
	body, err := ioutil.ReadAll(response.Body)
	if err != nil {
		fmt.Printf("%s", err)
		os.Exit(1)
	}

	jwtKeys := JWTKeys{}

	err = jsoniter.Unmarshal(body, &jwtKeys)
	if err != nil {
		panic(err)
	}

	return jwtKeys

}

func GetJWKS(t *jwt.Token) (interface{}, error) {
	// Check the signing method

	var key JWTKey

	//Fetches cached keys
	keys := GetCachedJWKSKeys() //Gets the cached key from Auth0

	//Add In OB Api signed keys
	pubKey := os.Getenv("JWKS_RS256_PUBLIC_KEY")
	if pubKey == "" {
		log.Fatal("Error 'JWKS_RS256_PUBLIC_KEY' variable not set")
	}

	pubKey = strings.ReplaceAll(pubKey,"\n","")
	pubKey = strings.ReplaceAll(pubKey,"-----BEGIN PUBLIC KEY-----","")
	pubKey = strings.ReplaceAll(pubKey,"-----END PUBLIC KEY-----","")


	keys.Keys = append(keys.Keys, JWTKey{
		Alg: "RS256",
		Kid: "ob-key1",
		Kty: "RSA",
		Use: "sig",
		X5c: []string{pubKey},
	})

	keyMap := map[string]JWTKey{}

	for _, v := range keys.Keys {
		keyMap[v.Kid] = v
	}

	askingKeyID := t.Header["kid"].(string)

	if k, ok := keyMap[askingKeyID]; ok {
		key = k
	} else {
		auth0keys := ParseJWKSAuth0() //If the cached key does not match then we fetch the latest keys from Auth0
		for _, vx := range auth0keys.Keys {
			if vx.Kid == t.Header["kid"] {
				key = vx
			} else {
				return nil, fmt.Errorf("Error - no keys found for kid=%v", t.Header["kid"])
			}
		}
	}

	parsedKey, err := jwt.ParseRSAPublicKeyFromPEM([]byte("-----BEGIN CERTIFICATE-----\n" + key.X5c[0] + "\n-----END CERTIFICATE-----"))
	if err != nil {
		panic(err)
	}
	return parsedKey, nil
}
